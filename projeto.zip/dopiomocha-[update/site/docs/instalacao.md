# Instalação — Doppio Mocha

## Requisitos
- PHP 8.1 ou superior com extensões PDO e PDO MySQL habilitadas.
- MySQL 8 ou compatível.
- Navegador atualizado.

> Este projeto pode ser executado localmente pelo XAMPP (Apache + MySQL). Não abra os arquivos PHP diretamente pelo navegador nem use o botão de visualização do editor.

## 1. Copiar o projeto para o XAMPP
1. Extraia a pasta do projeto.
2. Copie a pasta `site` para `C:\xampp\htdocs\doppio-mocha`.
3. No painel do XAMPP, inicie **Apache** e **MySQL**.

## 2. Preparar o banco de dados
1. Acesse `http://localhost/phpmyadmin`.
2. Abra a aba **Importar**.
3. Selecione `database/doppio_mocha.sql` e clique em **Importar/Executar**.
4. O script cria o banco `doppio_mocha`, as tabelas, categorias e produtos iniciais.

## 2. Configurar a conexão
Abra `config/conexao.php` e ajuste host, nome do banco, usuário e senha de acordo com sua instalação MySQL. O padrão do projeto é `localhost`, banco `doppio_mocha`, usuário `root` e senha vazia (altere para as credenciais do seu ambiente).

## 3. Configurar a conexão e abrir o site
Confira `config/conexao.php`. No XAMPP padrão, o host é `localhost`, o banco `doppio_mocha`, o usuário `root` e a senha fica vazia.

Abra no navegador: `http://localhost/doppio-mocha/html/index.php`.

## 4. Primeiro acesso
- Crie uma conta pela opção **Entrar** e depois **Cadastre-se**.
- Entre com o e-mail e a senha cadastrados.
- Adicione produtos ao carrinho, revise quantidades e avance para o pagamento demonstrativo.
- Consulte os pedidos em **Minha conta**.

## Observações
- O pagamento é apenas demonstrativo; não existe integração com gateway e nenhum dado de cartão é coletado.
- O carrinho fica no armazenamento local do navegador. Os pedidos confirmados são gravados no MySQL.
- Nunca publique credenciais reais no repositório. Configure usuário próprio e senha forte no MySQL.
