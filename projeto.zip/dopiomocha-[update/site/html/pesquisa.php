<?php
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../includes/funcoes.php';

$termo = trim((string)($_GET['q'] ?? ''));
$categoriaSelecionada = trim((string)($_GET['categoria'] ?? ''));
$categorias = $pdo->query('SELECT nome FROM categorias ORDER BY nome')->fetchAll(PDO::FETCH_COLUMN);
$produtos = [];

if ($termo !== '' || $categoriaSelecionada !== '') {
    $sql = 'SELECT p.*, c.nome AS categoria
            FROM produtos p
            LEFT JOIN categorias c ON c.id = p.categoria_id
            WHERE p.ativo = 1';
    $parametros = [];

    if ($termo !== '') {
        $sql .= ' AND (p.nome LIKE :termo_nome OR p.descricao LIKE :termo_descricao OR c.nome LIKE :termo_categoria)';
        $like = '%' . $termo . '%';
        $parametros['termo_nome'] = $like;
        $parametros['termo_descricao'] = $like;
        $parametros['termo_categoria'] = $like;
    }
    if ($categoriaSelecionada !== '') {
        $sql .= ' AND c.nome = :categoria';
        $parametros['categoria'] = $categoriaSelecionada;
    }
    $sql .= ' ORDER BY p.nome ASC';
    $consulta = $pdo->prepare($sql);
    $consulta->execute($parametros);
    $produtos = $consulta->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pesquisar produtos | Doppio Mocha</title>
    <link rel="stylesheet" href="../css/code.css">
</head>
<body>
<?php require __DIR__ . '/../includes/cabecalho.php'; ?>
<main class="secao-produtos pagina-pesquisa">
    <section class="pesquisa-intro">
        <span class="subtitulo-secao">ENCONTRE SEU FAVORITO</span>
        <h1>O que você está procurando?</h1>
        <p>Pesquise cafés, bebidas geladas, combos e doces da Doppio Mocha.</p>
        <form class="form-pesquisa-pagina" action="pesquisa.php" method="get" role="search">
            <label class="sr-only" for="termo-pesquisa">Nome, descrição ou categoria</label>
            <input id="termo-pesquisa" type="search" name="q" value="<?= h($termo) ?>" placeholder="Digite o nome de um produto..." autocomplete="off" autofocus>
            <button type="submit">Pesquisar</button>
        </form>
        <form class="filtro-pesquisa" action="pesquisa.php" method="get">
            <input type="hidden" name="q" value="<?= h($termo) ?>">
            <label for="categoria-pesquisa">Filtrar por categoria</label>
            <select id="categoria-pesquisa" name="categoria">
                <option value="">Todas as categorias</option>
                <?php foreach ($categorias as $categoria): ?>
                    <option value="<?= h($categoria) ?>" <?= $categoriaSelecionada === $categoria ? 'selected' : '' ?>><?= h($categoria) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="botao-filtro">Aplicar filtro</button>
            <?php if ($termo !== '' || $categoriaSelecionada !== ''): ?><a href="pesquisa.php" class="limpar-pesquisa">Limpar</a><?php endif; ?>
        </form>
    </section>

    <?php if ($termo === '' && $categoriaSelecionada === ''): ?>
        <div class="pesquisa-dica"><span aria-hidden="true">☕</span><div><h2>Uma pausa com sabor começa aqui.</h2><p>Digite algo na busca acima para encontrar seu próximo pedido.</p></div></div>
    <?php else: ?>
        <div class="titulo-secao resultado-pesquisa-titulo">
            <div><span class="subtitulo-secao">RESULTADOS</span><h2><?= $termo !== '' ? 'Busca por “' . h($termo) . '”' : 'Produtos da categoria ' . h($categoriaSelecionada) ?></h2></div>
            <span><?= count($produtos) ?> produto(s) encontrado(s)</span>
        </div>
        <?php if (!$produtos): ?>
            <div class="pesquisa-sem-resultado"><h2>Não encontramos esse produto.</h2><p>Tente outro termo ou escolha uma categoria diferente.</p><a href="produtos.php">Ver todos os produtos</a></div>
        <?php else: ?>
            <div class="grade-produtos">
                <?php foreach ($produtos as $produto): ?>
                    <article class="produto">
                        <a class="produto-imagem" href="detalhes_produto.php?id=<?= (int)$produto['id'] ?>"><div class="icone-produto"><img src="../imagens/<?= h($produto['imagem'] ?: 'cafe.png') ?>" alt="<?= h($produto['nome']) ?>"></div></a>
                        <div class="produto-info">
                            <p class="categoria-produto"><?= h($produto['categoria'] ?? 'Especial') ?></p>
                            <h3><?= h($produto['nome']) ?></h3>
                            <p class="descricao-produto"><?= h($produto['descricao'] ?? '') ?></p>
                            <p class="preco"><?= moeda((float)$produto['preco']) ?></p>
                            <a class="link-detalhes" href="detalhes_produto.php?id=<?= (int)$produto['id'] ?>">Ver detalhes</a>
                            <?php if ((int)$produto['estoque'] > 0): ?>
                                <button type="button" class="botao-comprar" data-id="<?= (int)$produto['id'] ?>" data-nome="<?= h($produto['nome']) ?>" data-preco="<?= h((string)$produto['preco']) ?>" data-imagem="../imagens/<?= h($produto['imagem'] ?: 'cafe.png') ?>">Adicionar ao carrinho</button>
                            <?php else: ?><p class="texto-estoque">Indisponível no momento</p><?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</main>
<?php require __DIR__ . '/../includes/rodape.php'; ?>
</body>
</html>
